DATABASE_CONFIG = {
    'host': 'localhost',
    'user': 'root', 
    'password': '1742424139',  
    'database': 'Project_demo'
}
